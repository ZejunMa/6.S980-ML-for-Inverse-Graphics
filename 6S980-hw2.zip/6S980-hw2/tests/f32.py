import torch


def f32(x):
    return torch.tensor(x, dtype=torch.float32)
